<?php

	if (isset($_POST['id']) && isset($_POST['titre']) && isset($_POST['nbPage'])) {
		$id = $_POST['id'];
		$titre = $_POST['titre'];
		$nbPage = $_POST['nbPage'];
			 
		// include db handler
		require_once '../db/DB_Functions.php';
		$db = new DB_Functions();
		$db->modifierLivre($id,$titre, $nbPage);
		$reponse=array();
		$reponse["ETAT"]="SUCCES";
		echo json_encode($reponse);	
	   
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);	
	}
?>
