<?php
	if (isset($_POST['id'])) {
		$id = $_POST['id'];
			 
		// include db handler
		require_once '../db/DB_Functions.php';
		$db = new DB_Functions();
		$db->supprimerLivre($id);
		$reponse=array();
		$reponse["ETAT"]="SUCCES";
		echo json_encode($reponse);		
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);	
	}
?>
