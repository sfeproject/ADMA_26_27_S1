-- Création de la base de données (si ce n'est pas déjà fait)
CREATE DATABASE IF NOT EXISTS theme_db;
USE theme_db;

-- 1. Table Livre
CREATE TABLE IF NOT EXISTS Livre (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(255),
    nombre_pages INT,
    prix FLOAT
);

-- 2. Table Smartphone
CREATE TABLE IF NOT EXISTS Smartphone (
    id INT AUTO_INCREMENT PRIMARY KEY,
    modele VARCHAR(255),
    stockage_go INT,
    prix FLOAT
);

-- 3. Table Fruit
CREATE TABLE IF NOT EXISTS Fruit (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255),
    quantite INT,
    poids_kg FLOAT
);

-- 4. Table Animal
CREATE TABLE IF NOT EXISTS Animal (
    id INT AUTO_INCREMENT PRIMARY KEY,
    espece VARCHAR(255),
    age INT,
    poids_kg FLOAT
);

-- 5. Table Journal
CREATE TABLE IF NOT EXISTS Journal (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre_article VARCHAR(255),
    numero_edition INT,
    tarif FLOAT
);

-- 6. Table Jouet
CREATE TABLE IF NOT EXISTS Jouet (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom_jouet VARCHAR(255),
    age_requis INT,
    prix FLOAT
);

-- 7. Table Avion
CREATE TABLE IF NOT EXISTS Avion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    modele VARCHAR(255),
    capacite_passagers INT,
    vitesse_max_kmh FLOAT
);

-- 8. Table Vase
CREATE TABLE IF NOT EXISTS Vase (
    id INT AUTO_INCREMENT PRIMARY KEY,
    couleur VARCHAR(255),
    hauteur_cm INT,
    poids_kg FLOAT
);

-- 9. Table Ventilateur
CREATE TABLE IF NOT EXISTS Ventilateur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    marque VARCHAR(255),
    nombre_vitesses INT,
    puissance_watts FLOAT
);

-- 10. Table Lampe
CREATE TABLE IF NOT EXISTS Lampe (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type_ampoule VARCHAR(255),
    intensite_lumineuse_lumens INT,
    prix FLOAT
);

-- 11. Table Boisson
CREATE TABLE IF NOT EXISTS Boisson (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255),
    volume_ml INT,
    prix FLOAT
);

-- 12. Table Hotel
CREATE TABLE IF NOT EXISTS Hotel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom_hotel VARCHAR(255),
    nombre_etoiles INT,
    tarif_nuit FLOAT
);

-- 13. Table Mixeur
CREATE TABLE IF NOT EXISTS Mixeur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    marque VARCHAR(255),
    capacite_bol_ml INT,
    puissance_watts FLOAT
);

-- 14. Table Plante
CREATE TABLE IF NOT EXISTS Plante (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom_commun VARCHAR(255),
    frequence_arrosage_jours INT,
    hauteur_cm FLOAT
);

-- 15. Table Dictionnaire
CREATE TABLE IF NOT EXISTS Dictionnaire (
    id INT AUTO_INCREMENT PRIMARY KEY,
    langue VARCHAR(255),
    nombre_mots INT,
    poids_kg FLOAT
);

-- 16. Table Salle
CREATE TABLE IF NOT EXISTS Salle (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom_salle VARCHAR(255),
    capacite_personnes INT,
    superficie_m2 FLOAT
);

-- 17. Table Stage
CREATE TABLE IF NOT EXISTS Stage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sujet VARCHAR(255),
    duree_semaines INT,
    remuneration_mensuelle FLOAT
);

-- 18. Table Lunette
CREATE TABLE IF NOT EXISTS Lunette (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type_verre VARCHAR(255),
    correction INT,
    prix FLOAT
);

-- 19. Table Bateau
CREATE TABLE IF NOT EXISTS Bateau (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom_bateau VARCHAR(255),
    annee_construction INT,
    longueur_metres FLOAT
);

-- 20. Table Velo
CREATE TABLE IF NOT EXISTS Velo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    marque VARCHAR(255),
    nombre_vitesses INT,
    poids_kg FLOAT
);

-- 21. Table Ordinateur
CREATE TABLE IF NOT EXISTS Ordinateur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    processeur VARCHAR(255),
    memoire_ram_go INT,
    prix FLOAT
);

-- 22. Table Cafe
CREATE TABLE IF NOT EXISTS Cafe (
    id INT AUTO_INCREMENT PRIMARY KEY,
    origine VARCHAR(255),
    degre_intensite INT,
    prix_kg FLOAT
);

-- 23. Table Montre
CREATE TABLE IF NOT EXISTS Montre (
    id INT AUTO_INCREMENT PRIMARY KEY,
    materiau VARCHAR(255),
    etancheite_metres INT,
    prix FLOAT
);