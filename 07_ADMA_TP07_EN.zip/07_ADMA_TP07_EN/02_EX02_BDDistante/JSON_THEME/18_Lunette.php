<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Lunette");
        $lunettes = [];
        while ($row = $result->fetch_assoc()) {
            $lunettes[] = $row;
        }
        echo json_encode(["success" => true, "data" => $lunettes]);
        break;

    case 'ajouter':
        $type_monture = $_POST['type_monture'] ?? '';
        $indice_protection = $_POST['indice_protection'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if (!empty($type_monture)) {
            $stmt = $conn->prepare("INSERT INTO Lunette (type_monture, indice_protection, prix) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $type_monture, $indice_protection, $prix);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Lunette ajoutée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le type de monture est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $type_monture = $_POST['type_monture'] ?? '';
        $indice_protection = $_POST['indice_protection'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if ($id > 0 && !empty($type_monture)) {
            $stmt = $conn->prepare("UPDATE Lunette SET type_monture = ?, indice_protection = ?, prix = ? WHERE id = ?");
            $stmt->bind_param("sidi", $type_monture, $indice_protection, $prix, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Lunette modifiée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et type de monture valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Lunette WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Lunette supprimée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>