<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Velo");
        $velos = [];
        while ($row = $result->fetch_assoc()) {
            $velos[] = $row;
        }
        echo json_encode(["success" => true, "data" => $velos]);
        break;

    case 'ajouter':
        $type_velo = $_POST['type_velo'] ?? '';
        $nombre_vitesses = $_POST['nombre_vitesses'] ?? 0;
        $poids_kg = $_POST['poids_kg'] ?? 0.0;

        if (!empty($type_velo)) {
            $stmt = $conn->prepare("INSERT INTO Velo (type_velo, nombre_vitesses, poids_kg) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $type_velo, $nombre_vitesses, $poids_kg);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Vélo ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le type de vélo est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $type_velo = $_POST['type_velo'] ?? '';
        $nombre_vitesses = $_POST['nombre_vitesses'] ?? 0;
        $poids_kg = $_POST['poids_kg'] ?? 0.0;

        if ($id > 0 && !empty($type_velo)) {
            $stmt = $conn->prepare("UPDATE Velo SET type_velo = ?, nombre_vitesses = ?, poids_kg = ? WHERE id = ?");
            $stmt->bind_param("sidi", $type_velo, $nombre_vitesses, $poids_kg, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Vélo modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et type de vélo valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Velo WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Vélo supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>