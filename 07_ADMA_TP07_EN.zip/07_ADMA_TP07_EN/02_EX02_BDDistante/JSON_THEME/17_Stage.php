<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Stage");
        $stages = [];
        while ($row = $result->fetch_assoc()) {
            $stages[] = $row;
        }
        echo json_encode(["success" => true, "data" => $stages]);
        break;

    case 'ajouter':
        $intitule = $_POST['intitule'] ?? '';
        $duree_semaines = $_POST['duree_semaines'] ?? 0;
        $indemnite = $_POST['indemnite'] ?? 0.0;

        if (!empty($intitule)) {
            $stmt = $conn->prepare("INSERT INTO Stage (intitule, duree_semaines, indemnite) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $intitule, $duree_semaines, $indemnite);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Stage ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "L'intitulé est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $intitule = $_POST['intitule'] ?? '';
        $duree_semaines = $_POST['duree_semaines'] ?? 0;
        $indemnite = $_POST['indemnite'] ?? 0.0;

        if ($id > 0 && !empty($intitule)) {
            $stmt = $conn->prepare("UPDATE Stage SET intitule = ?, duree_semaines = ?, indemnite = ? WHERE id = ?");
            $stmt->bind_param("sidi", $intitule, $duree_semaines, $indemnite, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Stage modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et intitulé valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Stage WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Stage supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>