<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Lampe");
        $lampes = [];
        while ($row = $result->fetch_assoc()) {
            $lampes[] = $row;
        }
        echo json_encode(["success" => true, "data" => $lampes]);
        break;

    case 'ajouter':
        $type_ampoule = $_POST['type_ampoule'] ?? '';
        $intensite_lumineuse_lumens = $_POST['intensite_lumineuse_lumens'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if (!empty($type_ampoule)) {
            $stmt = $conn->prepare("INSERT INTO Lampe (type_ampoule, intensite_lumineuse_lumens, prix) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $type_ampoule, $intensite_lumineuse_lumens, $prix);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Lampe ajoutée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le type d'ampoule est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $type_ampoule = $_POST['type_ampoule'] ?? '';
        $intensite_lumineuse_lumens = $_POST['intensite_lumineuse_lumens'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if ($id > 0 && !empty($type_ampoule)) {
            $stmt = $conn->prepare("UPDATE Lampe SET type_ampoule = ?, intensite_lumineuse_lumens = ?, prix = ? WHERE id = ?");
            $stmt->bind_param("sidi", $type_ampoule, $intensite_lumineuse_lumens, $prix, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Lampe modifiée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et type d'ampoule valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Lampe WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Lampe supprimée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>