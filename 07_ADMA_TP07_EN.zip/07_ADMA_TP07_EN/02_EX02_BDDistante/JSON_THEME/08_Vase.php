<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Vase");
        $vases = [];
        while ($row = $result->fetch_assoc()) {
            $vases[] = $row;
        }
        echo json_encode(["success" => true, "data" => $vases]);
        break;

    case 'ajouter':
        $couleur = $_POST['couleur'] ?? '';
        $hauteur_cm = $_POST['hauteur_cm'] ?? 0;
        $poids_kg = $_POST['poids_kg'] ?? 0.0;

        if (!empty($couleur)) {
            $stmt = $conn->prepare("INSERT INTO Vase (couleur, hauteur_cm, poids_kg) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $couleur, $hauteur_cm, $poids_kg);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Vase ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "La couleur est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $couleur = $_POST['couleur'] ?? '';
        $hauteur_cm = $_POST['hauteur_cm'] ?? 0;
        $poids_kg = $_POST['poids_kg'] ?? 0.0;

        if ($id > 0 && !empty($couleur)) {
            $stmt = $conn->prepare("UPDATE Vase SET couleur = ?, hauteur_cm = ?, poids_kg = ? WHERE id = ?");
            $stmt->bind_param("sidi", $couleur, $hauteur_cm, $poids_kg, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Vase modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et couleur valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Vase WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Vase supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>