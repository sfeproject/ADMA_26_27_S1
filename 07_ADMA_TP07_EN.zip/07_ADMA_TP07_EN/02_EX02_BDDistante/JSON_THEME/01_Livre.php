<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Livre");
        $livres = [];
        while ($row = $result->fetch_assoc()) {
            $livres[] = $row;
        }
        echo json_encode(["success" => true, "data" => $livres]);
        break;

    case 'ajouter':
        $titre = $_POST['titre'] ?? '';
        $nombre_pages = $_POST['nombre_pages'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if (!empty($titre)) {
            $stmt = $conn->prepare("INSERT INTO Livre (titre, nombre_pages, prix) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $titre, $nombre_pages, $prix);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Livre ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le titre est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $titre = $_POST['titre'] ?? '';
        $nombre_pages = $_POST['nombre_pages'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if ($id > 0 && !empty($titre)) {
            $stmt = $conn->prepare("UPDATE Livre SET titre = ?, nombre_pages = ?, prix = ? WHERE id = ?");
            $stmt->bind_param("sidi", $titre, $nombre_pages, $prix, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Livre modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et titre valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Livre WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Livre supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>