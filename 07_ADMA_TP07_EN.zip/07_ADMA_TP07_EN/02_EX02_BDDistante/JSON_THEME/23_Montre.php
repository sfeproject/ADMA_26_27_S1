<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Montre");
        $montres = [];
        while ($row = $result->fetch_assoc()) {
            $montres[] = $row;
        }
        echo json_encode(["success" => true, "data" => $montres]);
        break;

    case 'ajouter':
        $marque = $_POST['marque'] ?? '';
        $etancheite_metres = $_POST['etancheite_metres'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if (!empty($marque)) {
            $stmt = $conn->prepare("INSERT INTO Montre (marque, etancheite_metres, prix) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $marque, $etancheite_metres, $prix);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Montre ajoutée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "La marque est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $marque = $_POST['marque'] ?? '';
        $etancheite_metres = $_POST['etancheite_metres'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if ($id > 0 && !empty($marque)) {
            $stmt = $conn->prepare("UPDATE Montre SET marque = ?, etancheite_metres = ?, prix = ? WHERE id = ?");
            $stmt->bind_param("sidi", $marque, $etancheite_metres, $prix, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Montre modifiée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et marque valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Montre WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Montre supprimée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>