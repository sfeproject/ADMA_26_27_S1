<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Cafe");
        $cafes = [];
        while ($row = $result->fetch_assoc()) {
            $cafes[] = $row;
        }
        echo json_encode(["success" => true, "data" => $cafes]);
        break;

    case 'ajouter':
        $origine = $_POST['origine'] ?? '';
        $intensite = $_POST['intensite'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if (!empty($origine)) {
            $stmt = $conn->prepare("INSERT INTO Cafe (origine, intensite, prix) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $origine, $intensite, $prix);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Café ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "L'origine est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $origine = $_POST['origine'] ?? '';
        $intensite = $_POST['intensite'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if ($id > 0 && !empty($origine)) {
            $stmt = $conn->prepare("UPDATE Cafe SET origine = ?, intensite = ?, prix = ? WHERE id = ?");
            $stmt->bind_param("sidi", $origine, $intensite, $prix, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Café modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et origine valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Cafe WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Café supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>