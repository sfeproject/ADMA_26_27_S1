<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Dictionnaire");
        $dictionnaires = [];
        while ($row = $result->fetch_assoc()) {
            $dictionnaires[] = $row;
        }
        echo json_encode(["success" => true, "data" => $dictionnaires]);
        break;

    case 'ajouter':
        $langue = $_POST['langue'] ?? '';
        $nombre_mots = $_POST['nombre_mots'] ?? 0;
        $poids_kg = $_POST['poids_kg'] ?? 0.0;

        if (!empty($langue)) {
            $stmt = $conn->prepare("INSERT INTO Dictionnaire (langue, nombre_mots, poids_kg) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $langue, $nombre_mots, $poids_kg);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Dictionnaire ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "La langue est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $langue = $_POST['langue'] ?? '';
        $nombre_mots = $_POST['nombre_mots'] ?? 0;
        $poids_kg = $_POST['poids_kg'] ?? 0.0;

        if ($id > 0 && !empty($langue)) {
            $stmt = $conn->prepare("UPDATE Dictionnaire SET langue = ?, nombre_mots = ?, poids_kg = ? WHERE id = ?");
            $stmt->bind_param("sidi", $langue, $nombre_mots, $poids_kg, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Dictionnaire modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et langue valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Dictionnaire WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Dictionnaire supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>