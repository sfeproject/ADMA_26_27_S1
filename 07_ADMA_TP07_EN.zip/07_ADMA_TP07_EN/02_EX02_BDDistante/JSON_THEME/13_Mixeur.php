<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Mixeur");
        $mixeurs = [];
        while ($row = $result->fetch_assoc()) {
            $mixeurs[] = $row;
        }
        echo json_encode(["success" => true, "data" => $mixeurs]);
        break;

    case 'ajouter':
        $marque = $_POST['marque'] ?? '';
        $capacite_bol_ml = $_POST['capacite_bol_ml'] ?? 0;
        $puissance_watts = $_POST['puissance_watts'] ?? 0.0;

        if (!empty($marque)) {
            $stmt = $conn->prepare("INSERT INTO Mixeur (marque, capacite_bol_ml, puissance_watts) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $marque, $capacite_bol_ml, $puissance_watts);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Mixeur ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "La marque est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $marque = $_POST['marque'] ?? '';
        $capacite_bol_ml = $_POST['capacite_bol_ml'] ?? 0;
        $puissance_watts = $_POST['puissance_watts'] ?? 0.0;

        if ($id > 0 && !empty($marque)) {
            $stmt = $conn->prepare("UPDATE Mixeur SET marque = ?, capacite_bol_ml = ?, puissance_watts = ? WHERE id = ?");
            $stmt->bind_param("sidi", $marque, $capacite_bol_ml, $puissance_watts, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Mixeur modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et marque valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Mixeur WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Mixeur supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>