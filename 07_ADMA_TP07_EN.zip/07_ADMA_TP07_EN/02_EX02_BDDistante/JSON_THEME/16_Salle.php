<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Salle");
        $salles = [];
        while ($row = $result->fetch_assoc()) {
            $salles[] = $row;
        }
        echo json_encode(["success" => true, "data" => $salles]);
        break;

    case 'ajouter':
        $nom_salle = $_POST['nom_salle'] ?? '';
        $capacite_personnes = $_POST['capacite_personnes'] ?? 0;
        $superficie_m2 = $_POST['superficie_m2'] ?? 0.0;

        if (!empty($nom_salle)) {
            $stmt = $conn->prepare("INSERT INTO Salle (nom_salle, capacite_personnes, superficie_m2) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $nom_salle, $capacite_personnes, $superficie_m2);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Salle ajoutée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le nom de la salle est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $nom_salle = $_POST['nom_salle'] ?? '';
        $capacite_personnes = $_POST['capacite_personnes'] ?? 0;
        $superficie_m2 = $_POST['superficie_m2'] ?? 0.0;

        if ($id > 0 && !empty($nom_salle)) {
            $stmt = $conn->prepare("UPDATE Salle SET nom_salle = ?, capacite_personnes = ?, superficie_m2 = ? WHERE id = ?");
            $stmt->bind_param("sidi", $nom_salle, $capacite_personnes, $superficie_m2, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Salle modifiée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et nom de salle valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Salle WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Salle supprimée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>