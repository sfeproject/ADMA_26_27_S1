<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Plante");
        $plantes = [];
        while ($row = $result->fetch_assoc()) {
            $plantes[] = $row;
        }
        echo json_encode(["success" => true, "data" => $plantes]);
        break;

    case 'ajouter':
        $nom_commun = $_POST['nom_commun'] ?? '';
        $frequence_arrosage_jours = $_POST['frequence_arrosage_jours'] ?? 0;
        $hauteur_cm = $_POST['hauteur_cm'] ?? 0.0;

        if (!empty($nom_commun)) {
            $stmt = $conn->prepare("INSERT INTO Plante (nom_commun, frequence_arrosage_jours, hauteur_cm) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $nom_commun, $frequence_arrosage_jours, $hauteur_cm);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Plante ajoutée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le nom commun est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $nom_commun = $_POST['nom_commun'] ?? '';
        $frequence_arrosage_jours = $_POST['frequence_arrosage_jours'] ?? 0;
        $hauteur_cm = $_POST['hauteur_cm'] ?? 0.0;

        if ($id > 0 && !empty($nom_commun)) {
            $stmt = $conn->prepare("UPDATE Plante SET nom_commun = ?, frequence_arrosage_jours = ?, hauteur_cm = ? WHERE id = ?");
            $stmt->bind_param("sidi", $nom_commun, $frequence_arrosage_jours, $hauteur_cm, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Plante modifiée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et nom commun valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Plante WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Plante supprimée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>