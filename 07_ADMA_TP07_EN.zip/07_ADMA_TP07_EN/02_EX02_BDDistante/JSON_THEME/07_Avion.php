<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Avion");
        $avions = [];
        while ($row = $result->fetch_assoc()) {
            $avions[] = $row;
        }
        echo json_encode(["success" => true, "data" => $avions]);
        break;

    case 'ajouter':
        $modele = $_POST['modele'] ?? '';
        $capacite_passagers = $_POST['capacite_passagers'] ?? 0;
        $vitesse_max_kmh = $_POST['vitesse_max_kmh'] ?? 0.0;

        if (!empty($modele)) {
            $stmt = $conn->prepare("INSERT INTO Avion (modele, capacite_passagers, vitesse_max_kmh) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $modele, $capacite_passagers, $vitesse_max_kmh);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Avion ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le modèle est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $modele = $_POST['modele'] ?? '';
        $capacite_passagers = $_POST['capacite_passagers'] ?? 0;
        $vitesse_max_kmh = $_POST['vitesse_max_kmh'] ?? 0.0;

        if ($id > 0 && !empty($modele)) {
            $stmt = $conn->prepare("UPDATE Avion SET modele = ?, capacite_passagers = ?, vitesse_max_kmh = ? WHERE id = ?");
            $stmt->bind_param("sidi", $modele, $capacite_passagers, $vitesse_max_kmh, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Avion modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et modèle valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Avion WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Avion supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>