<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Jouet");
        $jouets = [];
        while ($row = $result->fetch_assoc()) {
            $jouets[] = $row;
        }
        echo json_encode(["success" => true, "data" => $jouets]);
        break;

    case 'ajouter':
        $nom_jouet = $_POST['nom_jouet'] ?? '';
        $age_requis = $_POST['age_requis'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if (!empty($nom_jouet)) {
            $stmt = $conn->prepare("INSERT INTO Jouet (nom_jouet, age_requis, prix) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $nom_jouet, $age_requis, $prix);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Jouet ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le nom du jouet est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $nom_jouet = $_POST['nom_jouet'] ?? '';
        $age_requis = $_POST['age_requis'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if ($id > 0 && !empty($nom_jouet)) {
            $stmt = $conn->prepare("UPDATE Jouet SET nom_jouet = ?, age_requis = ?, prix = ? WHERE id = ?");
            $stmt->bind_param("sidi", $nom_jouet, $age_requis, $prix, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Jouet modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et nom de jouet valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Jouet WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Jouet supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>