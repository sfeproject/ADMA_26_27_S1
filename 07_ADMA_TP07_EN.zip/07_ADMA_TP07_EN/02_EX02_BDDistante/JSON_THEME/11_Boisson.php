<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Boisson");
        $boissons = [];
        while ($row = $result->fetch_assoc()) {
            $boissons[] = $row;
        }
        echo json_encode(["success" => true, "data" => $boissons]);
        break;

    case 'ajouter':
        $nom = $_POST['nom'] ?? '';
        $volume_ml = $_POST['volume_ml'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if (!empty($nom)) {
            $stmt = $conn->prepare("INSERT INTO Boisson (nom, volume_ml, prix) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $nom, $volume_ml, $prix);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Boisson ajoutée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le nom est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $nom = $_POST['nom'] ?? '';
        $volume_ml = $_POST['volume_ml'] ?? 0;
        $prix = $_POST['prix'] ?? 0.0;

        if ($id > 0 && !empty($nom)) {
            $stmt = $conn->prepare("UPDATE Boisson SET nom = ?, volume_ml = ?, prix = ? WHERE id = ?");
            $stmt->bind_param("sidi", $nom, $volume_ml, $prix, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Boisson modifiée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et nom valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Boisson WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Boisson supprimée avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>