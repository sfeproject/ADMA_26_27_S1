<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Bateau");
        $bateaux = [];
        while ($row = $result->fetch_assoc()) {
            $bateaux[] = $row;
        }
        echo json_encode(["success" => true, "data" => $bateaux]);
        break;

    case 'ajouter':
        $nom_bateau = $_POST['nom_bateau'] ?? '';
        $capacite_passagers = $_POST['capacite_passagers'] ?? 0;
        $longueur_metres = $_POST['longueur_metres'] ?? 0.0;

        if (!empty($nom_bateau)) {
            $stmt = $conn->prepare("INSERT INTO Bateau (nom_bateau, capacite_passagers, longueur_metres) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $nom_bateau, $capacite_passagers, $longueur_metres);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Bateau ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le nom du bateau est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $nom_bateau = $_POST['nom_bateau'] ?? '';
        $capacite_passagers = $_POST['capacite_passagers'] ?? 0;
        $longueur_metres = $_POST['longueur_metres'] ?? 0.0;

        if ($id > 0 && !empty($nom_bateau)) {
            $stmt = $conn->prepare("UPDATE Bateau SET nom_bateau = ?, capacite_passagers = ?, longueur_metres = ? WHERE id = ?");
            $stmt->bind_param("sidi", $nom_bateau, $capacite_passagers, $longueur_metres, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Bateau modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et nom de bateau valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Bateau WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Bateau supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>