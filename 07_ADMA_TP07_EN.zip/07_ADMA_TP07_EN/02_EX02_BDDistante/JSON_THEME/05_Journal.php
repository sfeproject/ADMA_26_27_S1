<?php
// Configuration de la base de données
$host = "localhost";
$db   = "theme_db";
$user = "root";
$pass = "";

// Connexion à MariaDB
$conn = new mysqli($host, $user, $pass, $db);

// Vérification de la connexion
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Échec de la connexion à la base de données"]));
}

// Récupération de l'action demandée (via POST ou GET)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'lister':
        $result = $conn->query("SELECT * FROM Journal");
        $journaux = [];
        while ($row = $result->fetch_assoc()) {
            $journaux[] = $row;
        }
        echo json_encode(["success" => true, "data" => $journaux]);
        break;

    case 'ajouter':
        $titre_article = $_POST['titre_article'] ?? '';
        $numero_edition = $_POST['numero_edition'] ?? 0;
        $tarif = $_POST['tarif'] ?? 0.0;

        if (!empty($titre_article)) {
            $stmt = $conn->prepare("INSERT INTO Journal (titre_article, numero_edition, tarif) VALUES (?, ?, ?)");
            $stmt->bind_param("sid", $titre_article, $numero_edition, $tarif);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Journal ajouté avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de l'ajout"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "Le titre de l'article est obligatoire"]);
        }
        break;

    case 'modifier':
        $id = $_POST['id'] ?? 0;
        $titre_article = $_POST['titre_article'] ?? '';
        $numero_edition = $_POST['numero_edition'] ?? 0;
        $tarif = $_POST['tarif'] ?? 0.0;

        if ($id > 0 && !empty($titre_article)) {
            $stmt = $conn->prepare("UPDATE Journal SET titre_article = ?, numero_edition = ?, tarif = ? WHERE id = ?");
            $stmt->bind_param("sidi", $titre_article, $numero_edition, $tarif, $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Journal modifié avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la modification"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID et titre d'article valides requis"]);
        }
        break;

    case 'supprimer':
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;

        if ($id > 0) {
            $stmt = $conn->prepare("DELETE FROM Journal WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "Journal supprimé avec succès"]);
            } else {
                echo json_encode(["success" => false, "message" => "Erreur lors de la suppression"]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "message" => "ID valide requis"]);
        }
        break;

    default:
        echo json_encode(["success" => false, "message" => "Action non reconnue"]);
        break;
}

$conn->close();
?>