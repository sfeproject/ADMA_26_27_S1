-- 1. Table Livre
CREATE TABLE IF NOT EXISTS Livre (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titre TEXT,
    nombre_pages INTEGER,
    prix REAL
);

-- 2. Table Smartphone
CREATE TABLE IF NOT EXISTS Smartphone (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    modele TEXT,
    stockage_go INTEGER,
    prix REAL
);

-- 3. Table Fruit
CREATE TABLE IF NOT EXISTS Fruit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT,
    quantite INTEGER,
    poids_kg REAL
);

-- 4. Table Animal
CREATE TABLE IF NOT EXISTS Animal (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    espece TEXT,
    age INTEGER,
    poids_kg REAL
);

-- 5. Table Journal
CREATE TABLE IF NOT EXISTS Journal (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titre_article TEXT,
    numero_edition INTEGER,
    tarif REAL
);

-- 6. Table Jouet
CREATE TABLE IF NOT EXISTS Jouet (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom_jouet TEXT,
    age_requis INTEGER,
    prix REAL
);

-- 7. Table Avion
CREATE TABLE IF NOT EXISTS Avion (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    modele TEXT,
    capacite_passagers INTEGER,
    vitesse_max_kmh REAL
);

-- 8. Table Vase
CREATE TABLE IF NOT EXISTS Vase (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    couleur TEXT,
    hauteur_cm INTEGER,
    poids_kg REAL
);

-- 9. Table Ventilateur
CREATE TABLE IF NOT EXISTS Ventilateur (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    marque TEXT,
    nombre_vitesses INTEGER,
    puissance_watts REAL
);

-- 10. Table Lampe (Remplace Chaussure)
CREATE TABLE IF NOT EXISTS Lampe (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type_ampoule TEXT,
    intensite_lumineuse_lumens INTEGER,
    prix REAL
);

-- 11. Table Boisson
CREATE TABLE IF NOT EXISTS Boisson (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT,
    volume_ml INTEGER,
    prix REAL
);

-- 12. Table Hotel
CREATE TABLE IF NOT EXISTS Hotel (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom_hotel TEXT,
    nombre_etoiles INTEGER,
    tarif_nuit REAL
);

-- 13. Table Mixeur
CREATE TABLE IF NOT EXISTS Mixeur (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    marque TEXT,
    capacite_bol_ml INTEGER,
    puissance_watts REAL
);

-- 14. Table Plante
CREATE TABLE IF NOT EXISTS Plante (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom_commun TEXT,
    frequence_arrosage_jours INTEGER,
    hauteur_cm REAL
);

-- 15. Table Dictionnaire
CREATE TABLE IF NOT EXISTS Dictionnaire (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    langue TEXT,
    nombre_mots INTEGER,
    poids_kg REAL
);

-- 16. Table Salle
CREATE TABLE IF NOT EXISTS Salle (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom_salle TEXT,
    capacite_personnes INTEGER,
    superficie_m2 REAL
);

-- 17. Table Stage
CREATE TABLE IF NOT EXISTS Stage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sujet TEXT,
    duree_semaines INTEGER,
    remuneration_mensuelle REAL
);

-- 18. Table Lunette
CREATE TABLE IF NOT EXISTS Lunette (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type_verre TEXT,
    correction INTEGER,
    prix REAL
);

-- 19. Table Bateau
CREATE TABLE IF NOT EXISTS Bateau (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom_bateau TEXT,
    annee_construction INTEGER,
    longueur_metres REAL
);

-- 20. Table Velo
CREATE TABLE IF NOT EXISTS Velo (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    marque TEXT,
    nombre_vitesses INTEGER,
    poids_kg REAL
);

-- 21. Table Ordinateur
CREATE TABLE IF NOT EXISTS Ordinateur (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    processeur TEXT,
    memoire_ram_go INTEGER,
    prix REAL
);

-- 22. Table Cafe
CREATE TABLE IF NOT EXISTS Cafe (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    origine TEXT,
    degre_intensite INTEGER,
    prix_kg REAL
);

-- 23. Table Montre
CREATE TABLE IF NOT EXISTS Montre (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    materiau TEXT,
    etancheite_metres INTEGER,
    prix REAL
);