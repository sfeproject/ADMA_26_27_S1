package com.votre.paquet

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class SQLiteMesure(
    context: Context?,
    name: String?,
    factory: SQLiteDatabase.CursorFactory?,
    version: Int
) : SQLiteOpenHelper(context, name, factory, version) {

    companion object {
        const val TABLE_NAME = "Mesure"
        const val COLUMN_ID = "id"
        const val COLUMN_TYPE_CAPTEUR = "type_capteur"
        const val COLUMN_DATE_TIME = "date_time"
        const val COLUMN_VAL_X = "valX"
        const val COLUMN_VAL_Y = "valY"
        const val COLUMN_VAL_Z = "valZ"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = ("CREATE TABLE $TABLE_NAME ("
                + "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "$COLUMN_TYPE_CAPTEUR TEXT, "
                + "$COLUMN_DATE_TIME TEXT, "
                + "$COLUMN_VAL_X REAL, "
                + "$COLUMN_VAL_Y REAL, "
                + "$COLUMN_VAL_Z REAL)")
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    // Méthode pour insérer une mesure
    fun insererMesure(typeCapteur: String, dateTime: String, x: Float, y: Float, z: Float) {
        
		
    }

    // Méthode pour lister toutes les mesures dans les Logs
    fun listerMesures() {
        
    }
}

