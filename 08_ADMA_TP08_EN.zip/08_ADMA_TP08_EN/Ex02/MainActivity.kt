package com.votre.paquet

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.votre.paquet.dataamb.ActivityMainamb
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), SensorEventListener {

    companion object {
        private const val TAG = "TP_Accelero_SQL"
        private const val INTERVAL_ENREGISTREMENT_MS = 2000L // 2 secondes
    }

    private lateinit var amb: ActivityMainamb
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    

    // Variable pour gérer l'intervalle de 2 secondes
    private var dernierTempsEnregistrement: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initApp()
    }

    private fun initApp() {
        // 1. Initialisation du View amb et affectation de la vue
        amb = ActivityMainamb.inflate(layoutInflater)
        setContentView(amb.root)

        // 2. Initialisation de l'assistant SQLite SQLiteMesure
        

        // 3. Initialisation des TextViews avec une valeur par défaut
        amb.txtX.text = "X : 0.0"
        amb.txtY.text = "Y : 0.0"
        amb.txtZ.text = "Z : 0.0"

        // 4. Initialisation du SensorManager et du capteur d'accélération
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        // 5. Configuration des écouteurs d'événements (boutons)
        ajouterEcouteur()
    }

    private fun ajouterEcouteur() {
        // Gestion du clic sur le bouton pour lister les mesures distantes via networkHelper
        
    }

    override fun onResume() {
        super.onResume()
        // Exécute le bloc uniquement si l'accéléromètre n'est pas null
        // (évite un NullPointerException si le terminal n'intègre pas ce capteur)
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onPause() {
        super.onPause()
        // Désenregistrement dans onPause() pour couper le capteur
        // en arrière-plan et économiser la batterie
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        // Traitement des variations de l'accéléromètre en temps réel
        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]

            // Mise à jour des TextViews avec les valeurs actuelles du capteur
            amb.txtX.text = "X : %.2f".format(x)
            amb.txtY.text = "Y : %.2f".format(y)
            amb.txtZ.text = "Z : %.2f".format(z)

            // Vérification si le Switch d'enregistrement est activé
            val isEnregistrementActif = amb.switchEnregistrement.isChecked

            if (isEnregistrementActif) {
                val tempsActuel = System.currentTimeMillis()
                // Vérifie si 2 secondes se sont écoulées depuis le dernier enregistrement
                if (tempsActuel - dernierTempsEnregistrement >= INTERVAL_ENREGISTREMENT_MS) {
                    dernierTempsEnregistrement = tempsActuel

                    // Récupération de la date et heure courante formatée
                    val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    val dateTimeStr = dateFormat.format(Date())

                    // Insertion dans la base de données SQLite via SQLiteMesure
                    
					
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Méthode obligatoire de l'interface SensorEventListener,
        // laissée vide ici
    }
}