-- Création de la base de données
CREATE DATABASE IF NOT EXISTS mesure;

-- Sélection de la base de données
USE mesure;

-- Création de la table Mesure
CREATE TABLE IF NOT EXISTS Mesure (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type_capteur VARCHAR(50) NOT NULL,
    date_time VARCHAR(20) NOT NULL,
    valX FLOAT NOT NULL,
    valY FLOAT NOT NULL,
    valZ FLOAT NOT NULL
);