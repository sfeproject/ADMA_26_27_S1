<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mesure";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(["status" => "erreur", "message" => "Échec de la connexion : " . $conn->connect_error]);
    exit();
}

// Vérification de la présence des paramètres POST envoyés par Volley (via getParams)
if (isset($_POST['type_capteur']) && isset($_POST['date_time']) && isset($_POST['valX']) && isset($_POST['valY']) && isset($_POST['valZ'])) {
    
    $type = $conn->real_escape_string($_POST['type_capteur']);
    $date = $conn->real_escape_string($_POST['date_time']);
    $x = floatval($_POST['valX']);
    $y = floatval($_POST['valY']);
    $z = floatval($_POST['valZ']);

    $sql = "INSERT INTO Mesure (type_capteur, date_time, valX, valY, valZ) VALUES ('$type', '$date', $x, $y, $z)";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["status" => "succes", "message" => "Mesure enregistrée avec succès"]);
    } else {
        echo json_encode(["status" => "erreur", "message" => "Erreur SQL : " . $conn->error]);
    }
} else {
    echo json_encode(["status" => "erreur", "message" => "Paramètres POST manquants"]);
}

$conn->close();
?>