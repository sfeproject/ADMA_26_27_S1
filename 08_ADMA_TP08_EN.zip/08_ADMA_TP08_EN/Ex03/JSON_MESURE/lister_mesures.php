<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mesure";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(["status" => "erreur", "message" => "Échec de la connexion : " . $conn->connect_error]);
    exit();
}

$sql = "SELECT * FROM Mesure";
$result = $conn->query($sql);

$mesures = array();

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $mesures[] = $row;
    }
    echo json_encode(["status" => "succes", "data" => $mesures]);
} else {
    echo json_encode(["status" => "succes", "data" => [], "message" => "Aucune mesure trouvée"]);
}

$conn->close();
?>