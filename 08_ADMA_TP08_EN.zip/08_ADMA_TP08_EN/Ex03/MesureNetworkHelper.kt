package com.votre.paquet

import android.content.Context
import android.util.Log
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class MesureNetworkHelper(private val context: Context) {

    private val TAG = "MesureNetworkHelper"

    // Envoi d'une mesure en POST avec gestion de la réponse du serveur
    fun envoyerMesureDistant(url: String, type: String, date: String, x: Float, y: Float, z: Float) {
        
    }

    // Récupération de la liste en GET avec gestion des erreurs serveur
    fun listerMesuresDistant(url: String) {
        
    }
}