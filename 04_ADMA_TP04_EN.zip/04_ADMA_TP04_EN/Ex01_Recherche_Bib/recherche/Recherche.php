<?php
	if ( isset($_REQUEST['titre'])) {
		$titre = $_REQUEST['titre'];
		// include db handler
		require_once '../db/DB_Functions.php';
		$db = new DB_Functions();
		$db->rechercher($titre);
		
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}							
?>	
